/*---------------------------------------------------------------------------
  QN code testing and verification
  student copy
---------------------------------------------------------------------------*/
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <float.h>
#include <time.h>
#include <math.h>

#define LOOP_DELAY (1<<27)

// QN math functions which pass the number of bits "n" 
#define Qn_MULTIPLY(A,B,n) ((A>>(n/2))*(B >>(n-(n/2))))
#define Qn_DIVIDE(A,B,n) ((int) (((long int)(A)<<n)/(B) ))

// QN math and printing functions
void  printBinary(unsigned num, short N);
int  floatToFixed(double x, int n);
float fixedToFloat(int x, int n); 

/*---------------------------------------------------------------------------
  QN testing framework 
---------------------------------------------------------------------------*/
int main(int argc, char *argv[]) {
   // QN testing variables, add more as necessary
   double fnum1, fnum2, fnum3;
   int  qnum1, qnum2, qnum3, qnval;
   clock_t  time1, time2;
   unsigned i;
   
   
   //------------------------------------------------------------------------
   // Examine the division utilities
   //------------------------------------------------------------------------   
   printf("\nDivision test\n");
 
   
   
   //------------------------------------------------------------------------
   // Examine the multiplication utilities
   //------------------------------------------------------------------------   
   printf("\nMultiplication test\n");
 
   

   //------------------------------------------------------------------------
   // Implement floating point scientific equations two different ways
   // using normal fractions and using decimal fractions
   //------------------------------------------------------------------------
   printf("\nComplex calculations test\n");

   
   //---------------------------------------------------------------------
   // Implement QN scientific equations: x**3-.0001x**2-676X+.0676
   //------------------------------------------------------------------------   
  
   // print all 3 answers

   
   //------------------------------------------------------------------------
   // Examine the performance 
   //------------------------------------------------------------------------
   printf("\nPerformance test\n");

   // Floating point addition
   time1 = clock();
   for(i = 0; i < LOOP_DELAY; i++) {
      // Insert your addition here
   }
   time1 = clock()-time1;
   
   // QN addition
   time2 = clock();
   for(i = 0; i < LOOP_DELAY; i++) {
      // Insert your addition here
   }
   time2 = clock()-time2;
   
   // Print out the clicks and who was faster

   
   // Floating multiplication
   time1 = clock();
   for(i = 0; i < LOOP_DELAY; i++) {
      // Insert your addition here
   }
   time1 = clock()-time1;
   
   // QN multiplication
   time2 = clock();
   for(i = 0; i < LOOP_DELAY; i++) {
      // Insert your addition here
   }
   time2 = clock()-time2;
   
   // Print out the clicks and who was faster
 

   return(0);
}


/*---------------------------------------------------------------------------
  This prints a number in character binary bracketed by [..]
  
  Where: unsigned num - number to print
         short N      - number of bits to print
         
  Returns: nothing
  Error handling: none
----------------------------------------------------------------------------*/
void printBinary(unsigned num, short N) { 
   unsigned i; 
   printf("\t[");
   
   for (i = 1 << (N-1); i > 0; i = i >> 1) {
      (num & i)? printf("1"): printf("0");
    }        
   printf("]\n");
   return;
} 


/*---------------------------------------------------------------------------
  This convert from Float to FP(Qn) 
  
  Where: double x  - number to convert
         int qnval - number of bits to use
         
  Returns: int    - QN encoded number
  Error handling: none
----------------------------------------------------------------------------*/
int floatToFixed(double x, int qnval) { 
   return( x * (double)(1 << qnval) );            
} 

/*---------------------------------------------------------------------------
  This converts from FP(Qn) to Float
  
  Where: int x     - number to convert
         int qnval - number of bits to use
         
  Returns: float   - converted number
  Error handling: none
----------------------------------------------------------------------------*/
float fixedToFloat(int x, int qnval) { 
   return((double)x / (double) (1 << qnval));
}

